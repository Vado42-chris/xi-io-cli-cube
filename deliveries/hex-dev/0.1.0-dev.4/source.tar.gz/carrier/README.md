# HEX native carrier candidate — NOT YET COMPILED OR RELEASED

Reuses xi-io.net PR1109 neutral Tauri shell, source commit
5762432aa7aefde768dda97652c3368f27c95086. Replaces its remote preview projection
with immutable bundled accepted Cube frontend. No product UI files changed.

Assembly contract:
- carrier/frontend/ must contain built current accepted Cube UI (index.html,
  assets), with original shared window frame and NativeInstallerPanel.
- ../adapter/installer_adapter.py plus its own fixed dependencies/payload are
  packaged under resources/adapter/. Adapter consumes one JSON request on stdin
  and emits one JSON response; Python isolation -I means adapter must explicitly
  load its trusted bundled modules, not rely on PYTHONPATH/current directory.
- Fixed /usr/bin/python3 3.10+ required; no arbitrary process API is exposed.
  UI node selection is forwarded for the adapter's finite runtime validation.
- Native output max2MiB, request max16KiB. Raw stderr never reaches UI.
- At120s transport returns do_not_retry/uncertain WITHOUT killing subprocess;
  tracker retains serialization until child exits. Busy calls refuse with
  uncertain state; UI must consult saved history/readback after completion.
  Backend MUST also own cross-process locking and crash/reopen reconciliation:
  this carrier's mutex only covers one native process. Closing HEX does not
  prove that its child process or transaction stopped.

Finite commands:
- installer_request: inspect/prepare/readback/apply/rollback only.
- native_product_window: existing shared frame state/drag/minimize/maximize/
  close/resize, acting on invoking local HEX window only.
No native bridge permitted on external navigation. No remote origin ACLs;
no shell/fs plugins; only fixed bundled code is executed.

Build (parent owns build/toolchain/sysroot): npm install --ignore-scripts;
npm run test:contract; cargo test --manifest-path src-tauri/Cargo.toml;
npm run build:native. Establish a lockfile and compatible Linux baseline before
release. Debian13-built binaries must not be assumed compatible with Aries.
App identifier com.xiio.hex.candidate isolates WebView state from regular apps.

Passed now: five source/config boundary checks (Python).
Not performed: Rust compilation/tests, native IPC integration, GUI interaction,
package installation or Aries acceptance. These are mandatory before claiming
an installable working product. No host changes or release publication made.
