# HEX / CLI integration candidate — not a qualified release

## Product and sequence

HEX is the reusable installer baseline. The CLI is its first product. Reuse the
owner's existing AI Studio UI, supplied window carrier, CLI installation engine,
framework contracts and product repositories. Do not rebuild Studio, Ibal,
Switchboard, Ward, Reaper, Media Center or Benchmark interfaces here.

The required outcome is installation and authorized connection, not file copy:
preflight -> chosen payload location -> reviewed installation/repair -> required
headless runtime configuration -> explicitly approved startup/admission -> real
operation -> independent byte readback and original Work return.

One computer must operate independently. Multiple machine nodes are a baseline
capability, not a second bespoke bridge. Current owner recovery order is Loki
(existing headless server, preserve and repair) before Aries (workstation joining
the verified server). This is not a permanent hardware-role restriction.

Linux / Pop!_OS is the established target. Ubuntu 22.04 build compatibility is
preparation, not proof of operation on the owner's machines.

## Required gates

- Preserve regular third-party installations, profiles, files and sessions.
- Reuse versioned payload manifests, hashes, CLI generations and rollback.
- Keep application payloads separate from user/project data.
- Enforce actual least-privilege isolation; a directory is not a sandbox.
- Reuse the existing DEV / TEST / LIVE and trinity promotion contracts. A build,
  source check or package is not LIVE admission. No guessed environment layout.
- Recover existing identity/configuration metadata before asking the owner to
  reconstruct it. Never infer absence from a limited or unexported environment.
- No fabricated broker, Ward grant, BINS receipt, session or connected indicator.
- Credential/enrollment/network/security changes retain their exact approval
  requirements. Installer approval does not silently authorize unrelated apps.
- Other repos supply their own versioned payloads, installed only when those
  products meet the baseline. Their wider role census is not a bootstrap blocker.

## Current candidate evidence

The local source binds the existing frontend to a finite native installer API,
uses the existing CLI installer with verified offline payload transport, and
packages the pinned native connection consumer through existing kernel receipts.
Preflight and native directory chooser are bound; source/unit/temporary-root
installation checks exist. A native release and Debian candidate were built.

On 2026-10-26 at 11:03 UTC the actual packaged native window applied reviewed plan
`ddc21ddb63824e2f80120b1c65273463` inside the disposable Ubuntu 22.04 cloud rootfs.
It refused an unrelated nonempty folder, installed into a dedicated child folder,
and preserved the unrelated sentinel. All six CLI payload digests were separately
read and matched. A separate invocation of the installed launcher returned
`integrity_verified: true` and `active_release: true` for source `d53a1d0219f5...`.
Receipts are in `../receipts/gui-apply.jsonl` and
`../receipts/gui-installed-cli-independent-version.json`.

That version return also reports `SANDBOX_UNAVAILABLE_NAMESPACES_BLOCKED`.
It is not command execution qualification, host custody, or network connection
proof. The CLI subprocess test did not use a network namespace; it performed no
network operation. The original GUI fixture used a separate network namespace.
The revised DEV-isolated package was subsequently built and tested at 11:09 UTC:
`xi-io-hex-dev_0.1.0-dev.1_amd64.deb`, SHA-256
`cbeb9eb8b868a7c3ef8a46e712f78e8baf2efee0ed4f8b06c8b0afdbd99dfba6`.
Its real native window loaded the packaged resources, prepared and installed the
CLI, and a separately invoked installed launcher passed integrity readback.
After closing and reopening the window, the exact plan was retained; explicit
Check actual state again verified installed bytes. The DEV package has no
non-directory path overlap with the old HEX package; the old carrier binary
hash remained unchanged after extraction. This is an extracted-package cloud QA
fixture, not a host package-manager installation/uninstallation qualification.
Nine Rust tests and five source-contract checks passed. The existing Tauri
bundler-type warning leaves automatic package updater behavior unqualified.

The candidate was delivered for controlled DEV-only user installation at
11:10 UTC. Its delivery is not a claim that the user installed it. The user was
instructed to choose a dedicated test payload folder and not replace production
data; first-install rollback is explicitly unavailable.

Not established: complete packaged GUI end-to-end acceptance, real host service admission,
configured broker/authority ports, Loki/Aries connection, original Work return,
complete environment provisioning/promotion or local-Ollama-only formation proof.
The candidate must not be described as completing the required outcome.

## Source ownership

CLI payload: Vado42-chris/xi-io-cli at d53a1d0219f5b1707c6c1bbedfb262082179ceab.
UI baseline: Vado42-chris/xi-io-cli-cube at ffc9a3b751b47e6ce72876b64eb29f0232f865b5.
Carrier donor: xi-io.net PR #1109 at 5762432aa7aefde768dda97652c3368f27c95086.
Kernel: xi-io_installer at 15ce1769b773b3882e3f3965945ca91a29df98ec.
Connection consumer: xi-io-Switchboard at ffbcd216d4c673de826242662271add63112c49a.
Local adaptations are not claimed as accepted upstream commits or host custody.
